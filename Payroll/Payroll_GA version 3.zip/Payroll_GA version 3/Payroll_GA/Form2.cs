﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
namespace Payroll_GA
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {

        }

        private void btn_payroll_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3() ;
            form3.Show();
            this.Hide();
        }

        private void btn_benefits_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form1 loginPage = new Form1();
            loginPage.Show();
            this.Hide();
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            if (txt_hours.Text != "" && txt_wage.Text != "")
            {
                viewTable.Rows.Clear();
                double wage = double.Parse(txt_wage.Text);
                int hours = int.Parse(txt_hours.Text);
                double income = wage * hours;
                double tax = 0;
                if (rdo_tax1.Checked == true)
                {
                    if (income > 12500)
                    {
                        tax = income * 0.2;
                    }


                }
                else if (rdo_tax2.Checked == true)
                {
                    tax = income * 0.2;
                }

                else if (rdo_tax3.Checked == true)
                {
                    tax = income * 0.4;
                }


                viewTable.Rows.Add(tax, income, (income - tax));

            }
            else
            {
                MessageBox.Show("empty info");
            }
        }
    }

    //1250 = 0%
    //CBR = 20%
    //CD0 = 40%

    /*Nat Ins
     * 118-166 weekly 0%
     * 166.01-962 weekly 12%
     * 962+weekly (remainind) 2%*/

    
}
