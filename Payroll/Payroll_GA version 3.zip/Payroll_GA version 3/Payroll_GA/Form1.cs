﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


namespace Payroll_GA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        private NpgsqlConnection conn;
        string connstring = String.Format("Server={0};Port={1};" +
                      "User Id={2};Password={3};Database={4};", "localhost", 5432, "postgres", "Complete13", "postgres");

        private DataTable dt;
        private NpgsqlCommand cmd;
        private string sql = null;



        private void btn_login_Click(object sender, EventArgs e)
        {


            if (chk_terms.Checked)
            {

                try
                {
                    conn.Open();
                    sql = "Select * from login(:_username,:_password)";
                    cmd = new NpgsqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("_username", txt_username.Text);
                    cmd.Parameters.AddWithValue("_password", txt_password.Text);

                    int result = (int)cmd.ExecuteScalar();
                    if (result == 1)
                    {
                        Form2 MainPage = new Form2();
                        MainPage.Show();
                        this.Hide();
                        conn.Close();
                    }
                    else
                    {
                        MessageBox.Show("incorect password or user name ");
                        conn.Close();
                    }
                }
                catch (Exception msg)
                {

                    MessageBox.Show(msg.Message);
                }

               
            }
            else
            {
                MessageBox.Show("Error: You have not agreed to Terms and Conditions");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new NpgsqlConnection(connstring);
        }
    }
}
